<?php
declare(strict_types=1);
$cfg=dirname(__DIR__).'/config.php';
if(!is_file($cfg)){http_response_code(500);exit('Missing config.php. Copy config.example.php and configure your database.');}
$c=require $cfg;
session_name($c['session_name']??'smartline_admin');
session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS']),'samesite'=>'Lax']);
session_start();
try{$pdo=new PDO("mysql:host={$c['db_host']};dbname={$c['db_name']};charset=utf8mb4",$c['db_user'],$c['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}
catch(Throwable $e){http_response_code(500);exit('Database connection failed. Check config.php.');}
function h($s){return htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function token(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];}
function check_token(){if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(419);exit('Invalid form token. Refresh and retry.');}}
function auth(){if(empty($_SESSION['admin_id'])){header('Location: login.php');exit;}}
function head($title){echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.h($title).' · SMART LINE</title><link rel="stylesheet" href="style.css"></head><body><div class="layout"><aside><div class="logo"><b>S</b><span>SMART LINE<small>NETWORK BILLING</small></span></div><nav><a href="index.php">Overview</a><a href="customers.php">Customers</a><a href="packages.php">Packages</a><a href="vouchers.php">Vouchers</a></nav><small class="muted">ISP MANAGEMENT · MVP</small></aside><main><header><div><small>INTERNET SERVICE MANAGEMENT</small><h1>'.h($title).'</h1></div><a class="signout" href="logout.php">Sign out</a></header><section>';}
function foot(){echo '</section><footer>SMART LINE NETWORK · Billing MVP</footer></main></div></body></html>';}
