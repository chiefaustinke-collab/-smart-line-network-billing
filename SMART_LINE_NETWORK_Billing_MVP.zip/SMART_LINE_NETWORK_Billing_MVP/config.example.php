<?php
return [
 'db_host'=>'127.0.0.1',
 'db_name'=>'smartline_billing',
 'db_user'=>'smartline_user',
 'db_pass'=>'CHANGE_THIS_PASSWORD',
 'session_name'=>'smartline_admin',
];
