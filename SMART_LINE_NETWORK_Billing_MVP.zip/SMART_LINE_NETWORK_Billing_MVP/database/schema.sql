CREATE DATABASE IF NOT EXISTS smartline_billing CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smartline_billing;
CREATE TABLE admins (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE customers (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 customer_code VARCHAR(32) NOT NULL UNIQUE,
 full_name VARCHAR(160) NOT NULL,
 phone VARCHAR(32) NOT NULL,
 email VARCHAR(190) NULL,
 location VARCHAR(190) NULL,
 status ENUM('active','suspended','closed') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_customer_phone(phone)
) ENGINE=InnoDB;
CREATE TABLE packages (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 service_type ENUM('hotspot','pppoe','static_ip') NOT NULL,
 speed_down_mbps DECIMAL(8,2) NULL,
 speed_up_mbps DECIMAL(8,2) NULL,
 validity_days INT UNSIGNED NOT NULL DEFAULT 30,
 price_kes DECIMAL(12,2) NOT NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE vouchers (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 batch_code VARCHAR(40) NOT NULL,
 code_hash VARCHAR(255) NOT NULL,
 code_last4 CHAR(4) NOT NULL,
 package_id BIGINT UNSIGNED NOT NULL,
 status ENUM('unused','used','disabled') NOT NULL DEFAULT 'unused',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_voucher_package FOREIGN KEY(package_id) REFERENCES packages(id),
 INDEX idx_voucher_batch(batch_code)
) ENGINE=InnoDB;
