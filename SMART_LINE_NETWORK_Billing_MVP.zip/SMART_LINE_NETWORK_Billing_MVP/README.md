# SMART LINE NETWORK Billing MVP

PHP 8.1+ / MySQL starter application. Includes admin setup/login, dashboard, customer records, service packages and voucher batches.

## Install
1. Create a MySQL/MariaDB database and user.
2. Import `database/schema.sql`.
3. Copy `config.example.php` to `config.php` and set database credentials.
4. Set your hosting document root to the `public/` folder.
5. Visit `/setup.php` once to create the first administrator.
6. Delete `public/setup.php` immediately after setup.
7. Sign in at `/login.php`.

Local test: `php -S 127.0.0.1:8000 -t public`

## Scope
This is a functional initial admin MVP, not a complete production ISP billing platform. M-Pesa, live MikroTik provisioning, FreeRADIUS, PPPoE automation, SMS/WhatsApp, customer portal and scheduled expiry are future modules.

## Production security
Use HTTPS, keep config secrets outside public web root, use strong unique credentials, back up and test restores, add rate limiting and audit logs. Never expose MikroTik API, SSH, RADIUS or database ports publicly. Do not use live M-Pesa credentials until payment callbacks are verified and tested.
